close all;
clc;clear;
hold on
D=0:0.001:1;
vo_vs=1./(1-D);
plot(D,vo_vs);

rl_R=0.01;
vo_vs_re = (1-D)./((1 - D).^2+rl_R);
plot(D,vo_vs_re);

rl_R=0.1;
for j=1:4
    vo_vs_re = (1-D)./((1 - D).^2+rl_R);
    plot(D,vo_vs_re);
    rl_R=rl_R+0.2;
end
axis([0,1,0,8]);
xlabel('D'); ylabel('Vo/Vs'); title('Vo/Vs vs D');
hold off