close all;
clc;clear;
hold on;

R=10;
C=15e-6;
t=0:0.00001:0.001;
Vo=1;

Vot=Vo.*exp((-t)/(R*C));
plot(t,Vot);





hold off;

